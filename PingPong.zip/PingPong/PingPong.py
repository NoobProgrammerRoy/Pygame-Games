#Pygame imports
import pygame
import sys
import random
import math
from pygame.locals import *

class PingPong:
    #Instance variables
    fps = 30
    fpsclock = pygame.time.Clock()
    screenwidth = 600
    screenheight = 400
    screen = pygame.display.init()
    player1 = pygame.image.load('player1.png')
    player2 = pygame.image.load('player2.png')
    ball = pygame.image.load('ball.png')
    base = pygame.image.load('base.png')
    fpsclock = pygame.time.Clock()

    #Initializes the screen
    def initscreen(self):
        self.screen = pygame.display.set_mode((self.screenwidth,self.screenheight))
        pygame.display.set_caption('Ping Pong')

    #MainGame
    def mainGame(self):
        #Score counter
        player1Score = 0
        player2Score = 0
        font = pygame.font.Font('freesansbold.ttf',32)

        #Initial player positions
        player1X = 50
        player1Y = random.randint(50,280)

        player2X = 530
        player2Y = random.randint(50,280)

        player1VelY = 0
        player2VelY = 0

        #Initial ball position
        ballX = int(self.screenwidth/2) - int(self.ball.get_width()/2)
        ballY = random.randint(100,300)
        ballXChange = 5
        ballYChange = 5

        #GameLoop
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN and event.key == K_w:
                    player1VelY = -5
                elif event.type == KEYDOWN and event.key == K_UP:
                    player2VelY = -5    
                elif event.type == KEYDOWN and event.key == K_s:
                    player1VelY = 5
                elif event.type == KEYDOWN and event.key == K_DOWN:
                    player2VelY = 5

            player1Y += player1VelY
            player2Y += player2VelY
            ballX += ballXChange
            ballY += ballYChange

            #Player movements
            if player1Y <= 0:
                player1VelY = 5 

            if player2Y <= 0:
                player2VelY = 5 

            if player1Y >= 330:
                player1VelY = -5

            if player2Y >= 330:
                player2VelY = -5

            #Ball movements
            if ballY <= 0:
                ballYChange = 5
            if ballY >= 376:
                ballYChange = -5
            if ballX <= -(self.ball.get_width()):
                player2Score += 1
                ballX = int(self.screenwidth/2) - int(self.ball.get_width()/2)
                ballY = random.randint(100,300)
            if ballX >= (self.screenwidth) + (self.ball.get_width()):
                player1Score += 1    
                ballX = int(self.screenwidth/2) - int(self.ball.get_width()/2)
                ballY = random.randint(100,300)

            #Collisions
            collision1 = self.isPlayer1Collide(player1X,player1Y,ballX,ballY)
            collision2 = self.isPlayer2Collide(player2X,player2Y,ballX,ballY)
            
            if collision1:
                ballXChange = 5
            if collision2:
                ballXChange = -5

            self.screen.blit(self.base,(0,0))
            self.screen.blit(self.player1,(player1X,player1Y))
            self.screen.blit(self.player2,(player2X,player2Y))
            self.screen.blit(self.ball,(ballX,ballY))
            score1 = font.render(str(player1Score),True,(255,255,255))
            score2 = font.render(str(player2Score),True,(255,255,255))
            self.screen.blit(score1,(10,10))
            self.screen.blit(score2,(570,10))
            pygame.display.update()
            self.fpsclock.tick(self.fps)

    #Functions to check for collision
    def isPlayer1Collide(self,playerX,playerY,ballX,ballY):
        if math.sqrt(math.pow(((playerX + 20) - ballX),2) + math.pow(((playerY + 35) - (ballY +12)),2)) <= 35:
            return True
        else:
            return False

    def isPlayer2Collide(self,playerX,playerY,ballX,ballY):
        if math.sqrt(math.pow((playerX - (ballX + 24)),2) + math.pow(((playerY + 35) - (ballY +12)),2)) <= 35:
            return True
        else:
            return False

#Initializes pygame and its modules
pygame.init()

#Object creation and start of game
p = PingPong()
p.initscreen()
p.mainGame()