#Imports required for our game
import random       
import sys
import pygame
import math
from pygame.locals import *

class SpaceGame:
    #Global variables
    fps = 30
    screenwidth = 600
    screenheight = 400
    screen = pygame.display.init()
    player = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\player.png')
    background = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\background.jpg')
    enemy = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\enemy.png')
    shoot = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\shoot.png')
    mainMenu = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\mainMenu.jpg')
    controlMenu = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\controlMenu.jpg')
    endMenu = pygame.image.load('C:\\Users\\Richu\\Python Programs\\Space Game\\endMenu.jpg')
    fpsclock = pygame.time.Clock()

    #Initializes the screen
    def initscreen(self):
        self.screen = pygame.display.set_mode((self.screenwidth,self.screenheight))
        pygame.display.set_caption('Space Wars')
    
    #MainMenu of the game
    def MainMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN and event.key == K_SPACE:
                    return
                else:
                    self.screen.blit(self.mainMenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)        

    #ControlMenu of the game
    def ControlMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN and event.key == K_SPACE:
                    return
                else:
                    self.screen.blit(self.controlMenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)

    #Main Space Wars game
    def MainGame(self):
        #Score counter
        scoreValue = 0      
        font = pygame.font.Font('freesansbold.ttf',32)

        #Initial Position of player
        playerX = int(self.screenwidth/2.1)
        playerY = int(self.screenheight/1.2)

        playerXChange = 0
        shootYChange = 0

        #Initial position of bullet
        shootX = 0
        shootY = int(self.screenheight/1.2)

        #Spawning 5 random enemies
        enemy1X = random.randrange(0,550)
        enemy1Y = random.randrange(0,20)

        enemy2X = random.randrange(0,550)
        enemy2Y = random.randrange(0,20)

        enemy3X = random.randrange(0,550)
        enemy3Y = random.randrange(0,20)

        enemy4X = random.randrange(0,550)
        enemy4Y = random.randrange(0,20)

        enemy5X = random.randrange(0,550)
        enemy5Y = random.randrange(0,20)

        #Positional changes of the 5 enemies
        enemy1XChange = 5
        enemy1YChange = 50

        enemy2XChange = 5
        enemy2YChange = 50

        enemy3XChange = 5
        enemy3YChange = 50

        enemy4XChange = 5
        enemy4YChange = 50

        enemy5XChange = 5
        enemy5YChange = 50

        #Boolean conditions
        playerCollision = False
        shootCollision = False
        shootState = False
        collision = False
        playerMovement = False

        #GameLoop
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    if not shootState:
                        shootX = int(playerX) + 26
                        shootYChange = -10
                        shootState = True
                if event.type == KEYDOWN and event.key == K_LEFT:
                    if not playerMovement:
                        playerXChange = -10
                        playerMovement = True
                if event.type == KEYDOWN and event.key == K_RIGHT:
                    if not playerMovement:
                        playerXChange = 10    
                        playerMovement = True

            #Loop
            shootY += shootYChange
            playerX += playerXChange
        
            #Enemy 1
            enemy1X += enemy1XChange
            collision = self.isCollision(shootX,shootY,enemy1X,enemy1Y)

            if collision:
                enemy1X = random.randrange(0,555)
                enemy1Y = random.randrange(0,20)
                shootY = playerY
                shootYChange = 0
                shootState = False
                scoreValue += 1
                print(score)

            if(enemy1X <= 0):
                enemy1XChange = 5
                enemy1Y += enemy1YChange
            
            if(enemy1X >= 555):
                enemy1XChange = -5
                enemy1Y += enemy1YChange

            if enemy1Y >= 300:
                return

            #Enemy2
            enemy2X += enemy2XChange
            collision = self.isCollision(shootX,shootY,enemy2X,enemy2Y)

            if collision:
                enemy2X = random.randrange(0,555)
                enemy2Y = random.randrange(0,20)
                shootY = playerY
                shootYChange = 0
                shootState = False
                scoreValue += 1
                print(score)


            if(enemy2X <= 0):
                enemy2XChange = 5
                enemy2Y += enemy2YChange
            
            if(enemy2X >= 555):
                enemy2XChange = -5
                enemy2Y += enemy2YChange

            if enemy2Y >= 300:
                return


            #Enemy3
            enemy3X += enemy3XChange
            collision = self.isCollision(shootX,shootY,enemy3X,enemy3Y)

            if collision:
                enemy3X = random.randrange(0,555)
                enemy3Y = random.randrange(0,20)
                shootY = playerY
                shootYChange = 0
                shootState = False
                scoreValue += 1
                print(score)


            if(enemy3X <= 0):
                enemy3XChange = 5
                enemy3Y += enemy3YChange
            
            if(enemy3X >= 555):
                enemy3XChange = -5
                enemy3Y += enemy3YChange

            if enemy3Y >= 300:
                return


            #Enemy4
            enemy4X += enemy4XChange
            collision = self.isCollision(shootX,shootY,enemy4X,enemy4Y)

            if collision:
                enemy4X = random.randrange(0,555)
                enemy4Y = random.randrange(0,20)
                shootY = playerY
                shootYChange = 0
                shootState = False
                scoreValue += 1
                print(score)


            if(enemy4X <= 0):
                enemy4XChange = 5
                enemy4Y += enemy4YChange
            
            if(enemy4X >= 555):
                enemy4XChange = -5
                enemy4Y += enemy4YChange

            if enemy4Y >= 300:
                return


            #Enemy5
            enemy5X += enemy5XChange
            collision = self.isCollision(shootX,shootY,enemy5X,enemy5Y)

            if collision:
                enemy5X = random.randrange(0,555)
                enemy5Y = random.randrange(0,20)
                shootY = playerY
                shootYChange = 0
                shootState = False
                scoreValue += 1
                print(score)


            if(enemy5X <= 0):
                enemy5XChange = 5
                enemy5Y += enemy5YChange
            
            if(enemy5X >= 555):
                enemy5XChange = -5
                enemy5Y += enemy5YChange

            if enemy5Y >= 300:
                return            

            #Player Movement
            if playerMovement:
                temp = playerX
                playerX += playerXChange
                if playerX - temp == -10 or playerX - temp == 10:
                    playerXChange = 0
                    playerMovement = False

            if(playerX <= 0):
                playerX = 0

            if(playerX >= 555):
                playerX = 555    

            if(shootY <= 0):
                shootY = playerY
                shootYChange = 0
                shootState = False

            #Blitting the required images
            self.screen.blit(self.background,(0,0))
            self.screen.blit(self.player,(playerX,playerY))
            self.screen.blit(self.enemy,(enemy1X,enemy1Y))
            self.screen.blit(self.enemy,(enemy2X,enemy2Y))
            self.screen.blit(self.enemy,(enemy3X,enemy3Y))
            self.screen.blit(self.enemy,(enemy4X,enemy4Y))
            self.screen.blit(self.enemy,(enemy5X,enemy5Y))
            score = font.render('Score : ' + str(scoreValue),True,(255,255,255))
            self.screen.blit(score,(10,10)) 
            if shootState:
                shootY += shootYChange
                self.screen.blit(self.shoot,(shootX,shootY))
            pygame.display.update()
            self.fpsclock.tick(self.fps)        

    #Function to check for collision between bullet and enemy
    def isCollision(self,shootX,shootY,enemyX,enemyY):
        distance = math.sqrt(math.pow(((shootX + 5) - (enemyX + 30)),2) + math.pow((shootY - (enemyY + 15)),2))
        if distance <= 30:
            return True
        else:
            return False

    #EndMenu
    def EndMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN and event.key == K_SPACE:
                    self.MainGame()
                else:
                    self.screen.blit(self.endMenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)        


#Initializes pygame and its modules
pygame.init()   

#Object creation and start of the game
spacegame = SpaceGame()
spacegame.initscreen()
spacegame.MainMenu()
spacegame.ControlMenu()
spacegame.MainGame()
spacegame.EndMenu()