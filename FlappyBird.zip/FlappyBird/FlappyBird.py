#Pygame imports
import pygame
import sys
import random
import math
from pygame.locals import *

class FlappyBird:
    #Global variables
    screenwidth = 300
    screenheight = 500
    fps = 30
    fpsclock = pygame.time.Clock()
    player1 = pygame.image.load('bird1.png')
    player2 = pygame.image.load('bird2.png')
    player3 = pygame.image.load('bird3.png')
    background = pygame.image.load('background.png')
    base = pygame.image.load('base.png')
    pipe1 = pygame.image.load('pipe.png')
    pipe2 = pygame.transform.rotate(pygame.image.load('pipe.png'),180)
    mainmenu = pygame.image.load('menu.png')
    controlmenu = pygame.image.load('controlMenu.png')
    screen = pygame.display.init()
   
    #Initializes the screen    
    def initscreen(self):
        self.screen = pygame.display.set_mode((self.screenwidth,self.screenheight))
        pygame.display.set_caption('Flappy Bird')

    #MainMenu
    def mainMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    return
                else:
                    self.screen.blit(self.mainmenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)

    #Control menu and character select
    def controlMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_1:
                    return
                if event.type == KEYDOWN and event.key == K_2:
                    self.player1 = self.player2
                    return
                if event.type == KEYDOWN and event.key == K_3:
                    self.player1 = self.player3
                    return            
                else:
                    self.screen.blit(self.controlmenu,(0,0))
                    self.screen.blit(self.base,(0,400))
                    self.screen.blit(self.player1,(40,180))    
                    self.screen.blit(self.player2,(130,180))
                    self.screen.blit(self.player3,(220,180))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)

    #MainGame
    def mainGame(self):
        #Initial player position
        playerX = int(self.screenwidth/3)
        playerY = int(self.screenheight/2.5)
        playerYChange = 3

        #Initial pipe positions
        pipe1X = 600
        pipe1Y = random.randint(150,350)
        pipe1revY = pipe1Y - 500

        pipe2X = 800
        pipe2Y = random.randint(150,350)
        pipe2revY = pipe2Y - 500

        pipe3X = 1000
        pipe3Y = random.randint(150,350)
        pipe3revY = pipe3Y - 500

        pipe4X = 1200
        pipe4Y = random.randint(150,350)
        pipe4revY = pipe4Y - 500

        #Important variables
        pipeXChange = -4
        playerFlying = False
        scoreValue = 0      
        font = pygame.font.Font('freesansbold.ttf',50)

        while True:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit()

                if event.type == KEYDOWN and event.key == K_SPACE:
                    playerYChange = -35
                    playerFlying = True

            #Player movement
            playerY += playerYChange
            if playerFlying == True:
                playerYChange = 3
                playerFlying = False

            #Generating pipes
            pipe1X += pipeXChange
            pipe2X += pipeXChange
            pipe3X += pipeXChange
            pipe4X += pipeXChange

            if pipe1X < -40:
                pipe1X = pipe4X + 200 
                pipe1Y = random.randint(150,350)
                pipe1revY = pipe1Y - 500

            if pipe2X < -40:
                pipe2X = pipe1X + 200
                pipe2Y = random.randint(150,350)
                pipe2revY = pipe2Y - 500

            if pipe3X < -40:
                pipe3X = pipe2X + 200
                pipe3Y = random.randint(150,350)
                pipe3revY = pipe3Y - 500

            if pipe4X < -40:
                pipe4X = pipe3X + 200
                pipe4Y = random.randint(150,350)
                pipe4revY = pipe4Y - 500            

            #Collision checker
            collision1 = self.isCollision(playerX,playerY,pipe1X,pipe1Y)
            collision2 = self.isCollision(playerX,playerY,pipe2X,pipe2Y)             
            collision3 = self.isCollision(playerX,playerY,pipe3X,pipe3Y)            
            collision4 = self.isCollision(playerX,playerY,pipe4X,pipe4Y)
            
            if collision1:
                return
            elif collision2:
                return
            elif collision3:
                return
            elif collision4:
                return
            elif playerY <= 0:
                return
            elif (playerY + 24) >= 400:
                return 
            
            #Score checker
            point1 = self.scoreCount(playerX,pipe1X)
            point2 = self.scoreCount(playerX,pipe2X)
            point3 = self.scoreCount(playerX,pipe3X)
            point4 = self.scoreCount(playerX,pipe4X)

            if point1:
                scoreValue+=1
            elif point2:
                scoreValue+=1
            elif point3:
                scoreValue+=1
            elif point4:
                scoreValue+=1

            #Blitting images
            self.screen.blit(self.background,(0,0))
            self.screen.blit(self.player1,(playerX,playerY))
            self.screen.blit(self.pipe1,(pipe1X,pipe1Y))
            self.screen.blit(self.pipe2,(pipe1X,pipe1revY))
            self.screen.blit(self.pipe1,(pipe2X,pipe2Y))
            self.screen.blit(self.pipe2,(pipe2X,pipe2revY))
            self.screen.blit(self.pipe1,(pipe3X,pipe3Y))
            self.screen.blit(self.pipe2,(pipe3X,pipe3revY))
            self.screen.blit(self.pipe1,(pipe4X,pipe4Y))
            self.screen.blit(self.pipe2,(pipe4X,pipe4revY))
            self.screen.blit(self.base,(0,400))
            score = font.render(str(scoreValue),True,(255,255,255))
            self.screen.blit(score,(140,30))
            pygame.display.update()
            self.fpsclock.tick(self.fps) 

    #Function to check for collision between player and pipe
    def isCollision(self,playerX,playerY,pipeX,pipeY):
        if ((playerY + 24) >= pipeY) and ((pipeX - (playerX + 16) <= 20) and ((pipeX + 40) - playerX >= -10)):
            return True
        elif (playerY <= (pipeY-100)) and ((pipeX - (playerX + 16) <= 20) and ((pipeX + 40) - playerX >= -10)):
            return True
        return False
    
    #Function to calculate score
    def scoreCount(self,playerX,pipeX):
        if(playerX - (pipeX + 40) == 0):
            return True

#Object creation and start of the game
pygame.init()
f = FlappyBird()
f.initscreen()
f.mainMenu()
f.controlMenu()
f.mainGame()