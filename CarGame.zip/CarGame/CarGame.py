#Pygame imports
import pygame
import random
import sys
import math
from pygame.locals import *

class CarGame:    
    #Global variables
    fps = 30
    fpsclock = pygame.time.Clock()
    screenwidth = 300
    screenheight = 500
    screen = pygame.display.init()
    car = pygame.image.load('car.png')
    enemy = pygame.image.load('enemy.png')
    road = pygame.image.load('road.png')
    mainmenu = pygame.image.load('mainmenu.png')
    endmenu = pygame.image.load('endmenu.png')

    #Initializes the screen
    def initscreen(self):
        self.screen = pygame.display.set_mode((self.screenwidth,self.screenheight))
        pygame.display.set_caption('Car Game')

    #MainMenu
    def mainMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    return
                else:
                    self.screen.blit(self.mainmenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)

    #MainGame                    
    def mainGame(self):
        #Score
        scoreValue = 0      
        font = pygame.font.Font('freesansbold.ttf',32)

        #Initial player positions
        playerX = int(self.screenwidth/2)
        playerY = 400
        playerXChange = 0

        #Initial enemy positions
        enemy1X = random.randint(20,260)
        enemy1Y = -50
        enemy1YChange = 10

        enemy2X = random.randint(20,260)
        enemy2Y = -100
        enemy2YChange = 10

        enemy3X = random.randint(20,260)
        enemy3Y = -150
        enemy3YChange = 10

        enemy4X = random.randint(20,260)
        enemy4Y = -200
        enemy4YChange = 10

        #GameLoop
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_LEFT:
                    playerXChange = -5
                if event.type == KEYDOWN and event.key == K_RIGHT:
                    playerXChange = 5        


            playerX += playerXChange
            enemy1Y += enemy1YChange
            enemy2Y += enemy2YChange
            enemy3Y += enemy3YChange
            enemy4Y += enemy4YChange

            #Function call to check for collisons
            collision1 = self.isCollision(playerX,playerY,enemy1X,enemy1Y)
            collision2 = self.isCollision(playerX,playerY,enemy2X,enemy2Y)
            collision3 = self.isCollision(playerX,playerY,enemy3X,enemy3Y)
            collision4 = self.isCollision(playerX,playerY,enemy4X,enemy4Y)
        
            if collision1:
                return

            if collision2:
                return

            if collision3:
                return

            if collision4:
                return            

            #Enemy movements
            if enemy1Y >= 500:
                scoreValue += 1
                print(score)
                enemy1X = random.randint(20,260)
                enemy1Y = -50

            if enemy2Y >= 500:
                scoreValue += 1
                print(score)
                enemy2X = random.randint(20,260)
                enemy2Y = -100

            if enemy3Y >= 500:
                scoreValue += 1
                print(score)
                enemy3X = random.randint(20,260)
                enemy3Y = -150        

            if enemy4Y >= 500:
                scoreValue += 1
                print(score)
                enemy4X = random.randint(20,260)
                enemy4Y = -200

            #Player movements
            if playerX <= 20:
                playerX = 20

            if playerX >= 260:
                playerX = 260    

            #Blitting images onto the screen
            self.screen.blit(self.road,(0,0))
            self.screen.blit(self.car,(playerX,playerY))
            self.screen.blit(self.enemy,(enemy1X,enemy1Y))
            self.screen.blit(self.enemy,(enemy2X,enemy2Y))
            self.screen.blit(self.enemy,(enemy3X,enemy3Y))
            self.screen.blit(self.enemy,(enemy4X,enemy4Y))
            score = font.render('Score : ' + str(scoreValue),True,(255,0,255))
            self.screen.blit(score,(10,10))
            pygame.display.update()
            self.fpsclock.tick(self.fps)

    #Function to check for collison
    def isCollision(self,playerX,playerY,enemyX,enemyY):
        if math.sqrt(math.pow((playerX - enemyX),2) + math.pow((playerY - enemyY),2)) < 20:
            return True 
        else:
            return False    

    #EndMenu
    def endMenu(self):
        while True:
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    self.mainGame()
                else:
                    self.screen.blit(self.endmenu,(0,0))
                    pygame.display.update()
                    self.fpsclock.tick(self.fps)

#Initializes pygame and its modules
pygame.init()
#Object creation and entry point of the program
cargame = CarGame()
cargame.initscreen()
cargame.mainMenu()
cargame.mainGame()
cargame.endMenu()